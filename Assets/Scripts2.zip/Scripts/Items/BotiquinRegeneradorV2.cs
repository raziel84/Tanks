﻿using UnityEngine;
using System.Collections;

public class BotiquinRegeneradorV2 : MonoBehaviour {

    private string tagJugador = "Player";
    public float vidaCurar = 10f;    
    private Complete.TankHealth scriptVida;
    private float tiempoTranscurrido = 0;
    private float duracion = 1;
    private bool huboColision = false;

    private void Update()
    {
        if (huboColision) { 
        tiempoTranscurrido = tiempoTranscurrido + Time.deltaTime;

        Debug.Log(tiempoTranscurrido);
        }
        if (tiempoTranscurrido > 0.9f && tiempoTranscurrido < 1.1f)
        {
            scriptVida.Curacion(vidaCurar);
            tiempoTranscurrido = 0;
            duracion--;
        }
         
        if (duracion == 0)
        {
            DestruirObjeto();
        }
    }

    void OnTriggerEnter(Collider info)
    {
        if (info.tag != tagJugador) return;

        transform.SetParent(info.transform);
        gameObject.GetComponent <MeshRenderer>().enabled = false;

        scriptVida = info.gameObject.GetComponent<Complete.TankHealth>();
        duracion = 5f;
        huboColision = true;

    }

    private void DestruirObjeto()
    {
        transform.SetParent(null);
        Destroy(gameObject);
    }
}
