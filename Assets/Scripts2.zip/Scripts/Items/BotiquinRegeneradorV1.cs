﻿using UnityEngine;
using System.Collections;

public class BotiquinRegeneradorV1 : MonoBehaviour {

    private string tagJugador = "Player";
    public float vidaCurar = 10f;
    public float curacion;
    private Complete.TankHealth scriptVida;
    private float timer;
    private bool pasoElTiempo = false;

    private void Update()
    {     

        if(timer > 0)
        {           
            timer = timer - Time.deltaTime;
            curacion = vidaCurar * Time.deltaTime;
            scriptVida.Curacion(curacion);
            pasoElTiempo = true;
        }
         
        if(timer < 0 && pasoElTiempo)
        {
            DestruirObjeto();
        }
    }

    void OnTriggerEnter(Collider info)
    {
        if (info.tag != tagJugador) return;

        transform.SetParent(info.transform);
        gameObject.GetComponent <MeshRenderer>().enabled = false;

        scriptVida = info.gameObject.GetComponent<Complete.TankHealth>();
        timer = 5f;

    }

    private void DestruirObjeto()
    {
        transform.SetParent(null);
        Destroy(gameObject);
    }
}
