﻿using UnityEngine;
using System.Collections;
using Complete;

public class Botiquin : MonoBehaviour {

    public float cantidadACurar = 25f;              //puntos a curar.
    private string playerTag = "Player";            //para comprobar si el collider que dispara el trigger es un jugador.

    void Update()
    {
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);     //para que el objeto rote una vez que se crea.
    }

    void OnTriggerEnter(Collider tank)
    {
        if (tank.tag == playerTag)                  //si el tag del del collider "tank" es igual al playerTag.
        {
            Complete.TankHealth vidaTanque = tank.gameObject.GetComponent<Complete.TankHealth>();   //se obtiene el script "Tankhealth" del tanque.
            vidaTanque.Curacion(cantidadACurar);        //se le pasa al script los puntos a curar para que haga el cálculo.
            Destroy(gameObject);                        //destruye el botiquin.                                                                 
        }
    }
}
